package com.example.autototem;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

public class AutoTotemMod implements ClientModInitializer {

    public static boolean enabled = true;
    public static int heartThreshold = 6; // 0-20 kalp

    private static KeyBinding settingsKey;

    @Override
    public void onInitializeClient() {
        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.autototem.settings",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                "category.autototem"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (settingsKey.wasPressed()) {
                client.setScreen(new SettingsScreen(client.currentScreen));
            }
            tryEquipTotem(client);
        });
    }

    private static void tryEquipTotem(MinecraftClient client) {
        if (!enabled) return;
        PlayerEntity player = client.player;
        if (player == null || client.interactionManager == null) return;

        float limit = Math.max(0, Math.min(20, heartThreshold)) * 2.0f;
        if (player.getHealth() > limit) return;
        if (player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;

        for (int i = 0; i < 36; i++) {
            if (player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                int screenSlot = (i < 9) ? i + 36 : i;
                client.interactionManager.clickSlot(
                        player.playerScreenHandler.syncId,
                        screenSlot,
                        40,
                        SlotActionType.SWAP,
                        player);
                return;
            }
        }
    }
}

package com.example.autototem;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class SettingsScreen extends Screen {

    private final Screen parent;

    public SettingsScreen(Screen parent) {
        super(Text.literal("Auto Totem"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int cy = this.height / 2;

        addDrawableChild(ButtonWidget.builder(statusText(), b -> {
                    AutoTotemMod.enabled = !AutoTotemMod.enabled;
                    b.setMessage(statusText());
                })
                .dimensions(cx - 100, cy - 60, 200, 20)
                .build());

        addDrawableChild(ButtonWidget.builder(Text.literal("-"), b ->
                        AutoTotemMod.heartThreshold = Math.max(0, AutoTotemMod.heartThreshold - 1))
                .dimensions(cx - 100, cy - 20, 40, 20)
                .build());

        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b ->
                        AutoTotemMod.heartThreshold = Math.min(20, AutoTotemMod.heartThreshold + 1))
                .dimensions(cx + 60, cy - 20, 40, 20)
                .build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Kapat"), b ->
                        this.client.setScreen(parent))
                .dimensions(cx - 100, cy + 40, 200, 20)
                .build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        int cx = this.width / 2;
        int cy = this.height / 2;
        context.drawCenteredTextWithShadow(this.textRenderer,
                "Tetiklenme: " + AutoTotemMod.heartThreshold + " kalp (" + (AutoTotemMod.heartThreshold * 2) + " can)",
                cx, cy - 12, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                "Mod: " + (AutoTotemMod.enabled ? "AÇIK" : "KAPALI"),
                cx, cy - 80, 0xFFFFFF);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private Text statusText() {
        return Text.literal("Durum: " + (AutoTotemMod.enabled ? "AÇIK" : "KAPALI"));
    }
}

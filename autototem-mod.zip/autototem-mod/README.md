# Auto Totem (Fabric, 1.21 ve 1.21.4)

Kurulum:
1. Fabric örnek modunun (fabric-example-mod) `gradlew`, `gradlew.bat` ve `gradle/` klasörünü bu projeye kopyala.
2. Bu klasörü GitHub'a yükle. Actions sekmesinden build'i çalıştır.
3. Artifacts'tan `autototem-1.21` veya `autototem-1.21.4` jar'ını indir, MJLauncher mods klasörüne at.

Kullanım: Oyunda K tuşu ile ayarlar ekranını aç. Durum butonu modu açar/kapatır, +/- ile kalp eşiğini (0-20) ayarlarsın.
